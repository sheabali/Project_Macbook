import ResetPasswordPage from "@/components/module/Auth/ResetPassword";

export default function Page() {
  return <ResetPasswordPage />;
}

