import ForgotPasswordPage from "@/components/module/Auth/ForgotPassword";

export default function Page() {
  return <ForgotPasswordPage />;
}

