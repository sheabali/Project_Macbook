import AdminDashboardModule from "@/components/module/Dashboard/Admin";

export default function DashboardPage() {
  return <AdminDashboardModule />;
}

